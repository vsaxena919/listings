<?php
echo 'code represents your sense';
?>