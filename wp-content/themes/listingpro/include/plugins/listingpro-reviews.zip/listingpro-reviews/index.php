<?php
echo 'code is represents your sense';
?>